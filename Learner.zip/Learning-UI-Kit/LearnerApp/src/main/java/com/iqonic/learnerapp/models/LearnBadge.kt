package com.iqonic.learnerapp.models

class LearnBadge {
    var img :Int=0
    var color :Int=0
    var name :String?=null
    var comment :String?=null
    var isLocked :Boolean=false
}