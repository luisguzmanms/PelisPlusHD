package com.iqonic.learnerapp.models

class LearnCategory {
    var img :Int=0
    var name :String?=null
    var isSelected:Boolean=false
}