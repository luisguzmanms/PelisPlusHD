package com.iqonic.learnerapp.models

class LearnChat {
    var people :LearnPeople?=null
    var chat :String?=null
    var isSender :Boolean=false

}