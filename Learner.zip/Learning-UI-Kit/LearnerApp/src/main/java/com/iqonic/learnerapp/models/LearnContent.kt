package com.iqonic.learnerapp.models

class LearnContent {
    var name :String?=null
    var subtitle :String?=null
    var type :String?=null
}