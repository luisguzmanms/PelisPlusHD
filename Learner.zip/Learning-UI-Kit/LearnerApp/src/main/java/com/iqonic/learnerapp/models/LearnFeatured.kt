package com.iqonic.learnerapp.models

class LearnFeatured {
    var img :Int=0
    var name :String?=null
    var price :String?=null
    var strikePrice :String=""
    var type:String?=null
    var students:String?=null
    var lectures:String?=null
}