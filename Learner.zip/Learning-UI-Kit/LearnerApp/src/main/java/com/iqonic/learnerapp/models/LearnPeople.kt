package com.iqonic.learnerapp.models

class LearnPeople {
    var img :Int=0
    var name :String?=null
    var isOnline :Boolean=false
    var subject :String?=null
    var email:String?=null




}