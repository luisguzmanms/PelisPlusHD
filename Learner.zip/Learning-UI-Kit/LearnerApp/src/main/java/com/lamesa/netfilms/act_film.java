package com.lamesa.netfilms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

import com.iqonic.learnerapp.R;

public class act_film extends AppCompatActivity {

    private TextView tvDescrip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvDescrip = findViewById(R.id.tvDescripFilm);
        tvDescrip.setMovementMethod(new ScrollingMovementMethod());

    }
}
