package com.lamesa.netfilms;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.iqonic.learnerapp.R;
import com.lamesa.netfilms.adapter.adapterCategoria;
import com.lamesa.netfilms.adapter.adapterDestacado;
import com.lamesa.netfilms.adapter.adapterFilm;
import com.lamesa.netfilms.model.modelCategoria;
import com.lamesa.netfilms.model.modelDestacado;
import com.lamesa.netfilms.model.modelFilm;

import java.util.ArrayList;
import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.lamesa.netfilms.metodos.getListaCategorias;
import static com.lamesa.netfilms.metodos.getListaContenido;
import static com.lamesa.netfilms.metodos.getListaDestacados;
import static com.lamesa.netfilms.metodos.getListaPeliculas;
import static com.lamesa.netfilms.metodos.getListaSeries;

public class act_main extends AppCompatActivity {

    private TextView mtvVerDestacados;
    private TextView mtvVerPeliculas;
    private TextView mtvVerSeries;
    private static NestedScrollView contenidoHome;
    private static LinearLayout contenidoSearch;
    public static  List<modelDestacado> mlistDestacado;
    public static List<modelFilm> mlistSeries;
    public static List<modelFilm> mlistPeliculas;
    public static List<modelCategoria> mlistCategoria;
    private static TextView tvTituloBusqueda;
    public static RecyclerView mrvBusqueda;
    private static EditText etBuscar;
    public static adapterFilm mAdapterBusqueda;
    private ImageView ivLimpiarBusqueda;
    private BottomNavigationView bottomNavigation;
    public static adapterFilm mAdapterSerie;
    public static adapterCategoria mAdapterCategoria;
    public static adapterFilm mAdapterPelicula;
    public static adapterDestacado mAdapterDestacado;
    public static RecyclerView mrvDestacado;
    public static RecyclerView mrvCategoria;
    public static RecyclerView mrvFilmPeliculas;
    public static RecyclerView  mrvFilmSeries;
    public static List<modelFilm> mlistContenido;
    public static List<modelFilm> mlistGenero;
    private ImageView ivAtrasSearch;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_main);
        VistasHome();
        CargarRecyclerHome();
        VistasSearch();
        CargarRvSearch();


    }


    private void CargarRecyclerHome(){

        //region LISTA CONTENIDO
        mlistContenido = new ArrayList<>();

        //endregion

        //region LISTA CONTENIDO
        mlistGenero= new ArrayList<>();

        //endregion

        //region LISTA DESTACADOS
        mrvDestacado = findViewById(R.id.rvDestacado);
        mrvDestacado.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        mrvDestacado.setItemAnimator(new DefaultItemAnimator());
        mlistDestacado = new ArrayList<>();
        mAdapterDestacado = new adapterDestacado(this, mlistDestacado);
        mrvDestacado.setAdapter(mAdapterDestacado);
        getListaDestacados(this);
        //endregion


        //region LISTA CATEGORIAS
        mrvCategoria = findViewById(R.id.rvCategorias);
        mrvCategoria.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        mrvCategoria.setItemAnimator(new DefaultItemAnimator());
        mlistCategoria = new ArrayList<>();
        mAdapterCategoria = new adapterCategoria(this, mlistCategoria);
        mrvCategoria.setAdapter(mAdapterCategoria);
        getListaCategorias(this);
        //endregion



        //region LISTA PELICULAS
        mrvFilmPeliculas = findViewById(R.id.rvPeliculas);
        mrvFilmPeliculas.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        mrvFilmPeliculas.setItemAnimator(new DefaultItemAnimator());
        mlistPeliculas = new ArrayList<>();
        mAdapterPelicula = new adapterFilm(this, mlistPeliculas);
        mrvFilmPeliculas.setAdapter(mAdapterPelicula);
        getListaPeliculas(this);
        //endregion



        //region LISTA SERIES
        mrvFilmSeries = findViewById(R.id.rvSeries);
        mrvFilmSeries.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        mrvFilmSeries.setItemAnimator(new DefaultItemAnimator());
        mlistSeries = new ArrayList<>();
        mAdapterSerie = new adapterFilm(this, mlistSeries);
        mrvFilmSeries.setAdapter(mAdapterSerie);
        getListaSeries(this);
        //endregion





    }

    private void VistasHome() {

        contenidoHome = findViewById(R.id.contenidoHome);
        contenidoSearch = findViewById(R.id.contenidoSearch);




        mtvVerPeliculas = findViewById(R.id.tvVerPeliculas);
        mtvVerSeries = findViewById(R.id.tvVerSeries);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (v.getId()) {


                    case R.id.tvVerPeliculas:

                        AbrirSearch(mlistPeliculas, "Peliculas", act_main.this);

                        break;


                    case R.id.tvVerSeries:

                        AbrirSearch(mlistSeries, "Series", act_main.this);

                        break;


                }


            }
        };


        mtvVerPeliculas.setOnClickListener(listener);
        mtvVerSeries.setOnClickListener(listener);





        BottomNavigation();

    }


    private void BottomNavigation(){
        bottomNavigation = findViewById(R.id.bottomNavigation);


        bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()){
                    case R.id.navigation_home:

                        contenidoSearch.setVisibility(GONE);
                        contenidoHome.setVisibility(VISIBLE);
                        menuItem.setChecked(true);
                        break;

                    case R.id.navigation_search:

                        contenidoSearch.setVisibility(VISIBLE);
                        contenidoHome.setVisibility(GONE);
                        AbrirSearch(mlistContenido, "Contenido", act_main.this);
                        getListaContenido(act_main.this);
                        menuItem.setChecked(true);
                        break;
                }

                return false;
            }
        });
    }


    private void VistasSearch() {
        tvTituloBusqueda = findViewById(R.id.tvTituloBusqueda);
        etBuscar = findViewById(R.id.etBuscar);
        ivLimpiarBusqueda = findViewById(R.id.ivLimpiarBusqueda);
        ivAtrasSearch = findViewById(R.id.ivAtrasSearch);


        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (v.getId()) {


                    case R.id.ivLimpiarBusqueda:

                        etBuscar.setText("");

                        break;

                    case R.id.ivAtrasSearch:

                        contenidoSearch.setVisibility(GONE);
                        contenidoHome.setVisibility(VISIBLE);

                        break;


                }


            }
        };


        ivLimpiarBusqueda.setOnClickListener(listener);
        ivAtrasSearch.setOnClickListener(listener);
    }


    private void CargarRvSearch() {
        mrvBusqueda = findViewById(R.id.rvFilmsBusqueda);
    }


    //cargar contenido shear y ocultarhome
    public static void AbrirSearch(final List<modelFilm> ListaParaMostrar, String TituloBusqueda, final Context mContext) {

        if (contenidoHome.getVisibility() != GONE) {
            contenidoHome.setVisibility(GONE);
            contenidoSearch.setVisibility(VISIBLE);
        }

        tvTituloBusqueda.setText(TituloBusqueda);


        CargarRvBusqueda(ListaParaMostrar, mContext);


        // metodo para filtrar la lista cargada en el rv de busqueda y volverla a cargar filtrada

        etBuscar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                //metodo para crear una nueva lista con los elementos filtrados y enviarla al adaptador

                FiltrarLista(s.toString(), ListaParaMostrar, mContext);

            }
        });


    }


    //metodo para crear una nueva lista con los elementos filtrados y enviarla al adaptador
    private static void FiltrarLista(String text, List<modelFilm> ListaParaFiltrar, Context mContext) {
        List<modelFilm> listaFiltrada = new ArrayList<>();

        for (int i = 0; ListaParaFiltrar.size() > i; i++) {
            if (ListaParaFiltrar.get(i).getNombre().toLowerCase().contains(text.toLowerCase())) {
                listaFiltrada.add(ListaParaFiltrar.get(i));
            }
        }


        mAdapterBusqueda = new adapterFilm(mContext, listaFiltrada);
        mrvBusqueda.setAdapter(mAdapterBusqueda);
    }


    //cargar una lista en el recyvlerview de el contenido search
    private static void CargarRvBusqueda(List ListaParaMostrar, Context mContext) {


        mrvBusqueda.setLayoutManager(new GridLayoutManager(mContext, 3));
        mrvBusqueda.setItemAnimator(new DefaultItemAnimator());
        mAdapterBusqueda = new adapterFilm(mContext, ListaParaMostrar);
        mrvBusqueda.setAdapter(mAdapterBusqueda);


    }

}
