package com.lamesa.netfilms;

import android.content.Context;
import android.widget.Toast;

import androidx.annotation.ContentView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.iqonic.learnerapp.R;
import com.lamesa.netfilms.adapter.adapterDestacado;
import com.lamesa.netfilms.adapter.adapterFilm;
import com.lamesa.netfilms.model.modelCategoria;
import com.lamesa.netfilms.model.modelDestacado;
import com.lamesa.netfilms.model.modelFilm;

import java.util.ArrayList;

import static com.lamesa.netfilms.act_main.AbrirSearch;
import static com.lamesa.netfilms.act_main.mAdapterBusqueda;
import static com.lamesa.netfilms.act_main.mAdapterCategoria;
import static com.lamesa.netfilms.act_main.mAdapterDestacado;
import static com.lamesa.netfilms.act_main.mAdapterPelicula;
import static com.lamesa.netfilms.act_main.mAdapterSerie;
import static com.lamesa.netfilms.act_main.mlistCategoria;
import static com.lamesa.netfilms.act_main.mlistContenido;
import static com.lamesa.netfilms.act_main.mlistDestacado;
import static com.lamesa.netfilms.act_main.mlistGenero;
import static com.lamesa.netfilms.act_main.mlistPeliculas;
import static com.lamesa.netfilms.act_main.mlistSeries;
import static com.lamesa.netfilms.act_main.mrvBusqueda;
import static com.lamesa.netfilms.act_main.mrvDestacado;

public class metodos {


    private static FirebaseAuth mAuth;
    public static FirebaseUser user;

    public static boolean LoginDeUsuario() {
        // NECESARIO PARA COMPROBAR EL INICIO DE SESION DE UN USUARIO
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();


        if (user != null) {
            return true;
        } else {
            return false;
        }
    }

    public static void getListaDestacados(Context mContext) {


        Query database = FirebaseDatabase.getInstance().getReference().child("data");


        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mlistDestacado.removeAll(mlistDestacado);

                for (DataSnapshot snapshot :
                        dataSnapshot.getChildren()) {


                    if (snapshot.child("destacado").exists()) {

                        Boolean destacar = (Boolean) snapshot.child("destacado").getValue();

                        if (destacar) {
                            modelDestacado destacado = snapshot.child("info").getValue(modelDestacado.class);
                            mlistDestacado.add(destacado);
                        }
                    }


                    System.out.println("CAMBIO :: ");


                }

                for (int i = 0; mlistDestacado.size() > i; i++) {
                    System.out.println("LOGNET :: " + mlistDestacado.get(i).getId());
                    System.out.println("LOGNET2 :: " + mlistDestacado.get(i).getImagen());
                    System.out.println("LOGNET3 :: " + mlistDestacado.get(i).getNombre());

                }

                mAdapterDestacado.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });


    }

    public static void getListaPeliculas(Context mContext) {


        Query database = FirebaseDatabase.getInstance().getReference().child("data");


        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mlistPeliculas.removeAll(mlistPeliculas);

                for (DataSnapshot snapshot :
                        dataSnapshot.getChildren()) {


                    if (snapshot.child("info").child("tipo").exists()) {

                        String tipo = (String) snapshot.child("info").child("tipo").getValue();

                        if (tipo.toLowerCase().contains("pelicula")) {
                            modelFilm pelicula = snapshot.child("info").getValue(modelFilm.class);
                            mlistPeliculas.add(pelicula);
                        }
                    }

                }


                mAdapterPelicula.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });


    }


    public static void getListaSeries(Context mContext) {


        Query database = FirebaseDatabase.getInstance().getReference().child("data");


        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mlistSeries.removeAll(mlistSeries);

                for (DataSnapshot snapshot :
                        dataSnapshot.getChildren()) {


                    if (snapshot.child("info").child("tipo").exists()) {

                        String tipo = (String) snapshot.child("info").child("tipo").getValue();

                        if (tipo.toLowerCase().contains("serie")) {
                            modelFilm serie = snapshot.child("info").getValue(modelFilm.class);
                            mlistSeries.add(serie);
                        }
                    }

                }


                mAdapterSerie.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });


    }


    public static void getListaCategorias(Context mContext) {


        Query database = FirebaseDatabase.getInstance().getReference().child("otros").child("categorias");


        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mlistCategoria.removeAll(mlistCategoria);

                for (DataSnapshot snapshot :
                        dataSnapshot.getChildren()) {


                    modelCategoria categoria = snapshot.getValue(modelCategoria.class);
                    mlistCategoria.add(categoria);


                }


                mAdapterCategoria.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });


    }


    public static void getListaGenero(final String Genero, final Context mContext) {


        Query database = FirebaseDatabase.getInstance().getReference().child("data");


        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mlistGenero.removeAll(mlistGenero);

                for (DataSnapshot snapshot :
                        dataSnapshot.getChildren()) {


                    if (snapshot.child("info").child("categoria").exists()) {

                        String genero =  snapshot.child("info").child("categoria").getValue().toString();

                        if (genero.toLowerCase().contains(Genero.toLowerCase())) {
                            modelFilm generoFilm = snapshot.child("info").getValue(modelFilm.class);
                            mlistGenero.add(generoFilm);
                        }
                    }

                }


                for (int i = 0; mlistGenero.size() > i; i++){
                    System.out.println("LOGNETT::GENERO "+mlistGenero.get(i).getNombre());
                }


                mAdapterBusqueda.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });


    }


    public static void getListaContenido(Context mContext) {


        Query database = FirebaseDatabase.getInstance().getReference().child("data");


        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mlistContenido.removeAll(mlistContenido);

                for (DataSnapshot snapshot :
                        dataSnapshot.getChildren()) {


                    if (snapshot.child("info").exists()) {


                            modelFilm film = snapshot.child("info").getValue(modelFilm.class);
                            mlistContenido.add(film);

                    }

                }


                mAdapterBusqueda.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });


    }

}
