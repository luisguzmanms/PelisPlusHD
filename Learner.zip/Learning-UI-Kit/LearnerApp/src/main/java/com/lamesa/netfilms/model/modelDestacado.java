package com.lamesa.netfilms.model;

public class modelDestacado {

    String imagen;
    String nombre;
    int id;

    public modelDestacado(){

    }

    public modelDestacado(int id, String imagen, String nombre) {

        this.id = id;
        this.imagen = imagen;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
